package com.find.parkkar;

public class StorePhoneNumber {

    String phoneNumber;

    public StorePhoneNumber(){

    }

    public StorePhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
}
